import numpy as np;
#from sklearn.impute import SimpleImputer as Imputer
from sklearn.preprocessing import Imputer

class Miss_Data:
    def __init__(self, dataset):
        self.dataset = dataset
        # self.dataset =pd.DataFrame(self.dataset)

    def clean(self):
        imputer = Imputer(missing_values=np.nan, strategy='mean')
        imputer = imputer.fit(self.dataset)
        dataset = imputer.transform(self.dataset)
        return dataset
