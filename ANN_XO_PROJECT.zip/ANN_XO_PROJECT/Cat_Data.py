import pandas as pd
import numpy as np


class Cat_Data:
    def __init__(self, dataset, featureNames):
        self.dataset = dataset
        self.featureNames = featureNames
        self.map = {}

    def defaule_clean_XO(self):
        i = 0
        row, col = self.dataset.shape
        dataset = np.zeros((row, col))
        while i < row:
            j = 0
            while j < col:
                if self.dataset[i][j] == "x":
                    dataset[i][j] = int(1)
                elif self.dataset[i][j] == "o":
                    dataset[i][j] = int(-1)
                elif self.dataset[i][j] == "b":
                    dataset[i][j] = int(0)
                elif self.dataset[i][j] == "False":
                    dataset[i][j] = int(0)
                elif self.dataset[i][j] == "True":
                    dataset[i][j] = int(1)
                j = j + 1
            i = i + 1
        dataset = pd.DataFrame(dataset)
        return dataset;

    def clean(self, use_defaul=False):
        if use_defaul == True:
            return self.defaule_clean_XO();

        newCleanDataSet = self.dataset;
        pandas_dataset = pd.DataFrame(self.dataset);
        # print(pandas_dataset[1])
        #self.Enter_Cat();
        i = -1
        for feature_i in self.featureNames:
            i = i + 1
            if self.map.get(feature_i) == None:
                continue
            map_i = self.map.get(feature_i)
            pandas_dataset[i] = pandas_dataset[i].map(map_i);
            print("kero");
        pandas_dataset = pandas_dataset.replace(r'\s+', np.nan, regex=True)
        return pandas_dataset;

    def Enter_Cat(self):
        print("press 1 to continue");
        for feature_i in self.featureNames:
            ans = input("do you want to add feature to :: > " + feature_i)
            if ans != "1":
                print(ans)
                continue
            cont = "cont"
            map_i = {};
            while cont != None:
                key = input("enter Key: ");
                if (key == ""):
                    break
                value = input("enter Value: ");
                map_i[key] = int(value);

            self.map[feature_i] = map_i;

    def push_key_value(self, column, key, value):
        if self.map.get(column) is None:
            self.map[column] = {}
        self.map[column][key] = value
