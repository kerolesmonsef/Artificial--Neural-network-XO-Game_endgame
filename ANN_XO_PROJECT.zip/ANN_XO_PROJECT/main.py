from Hebb_network import Hebb_network
from Cat_Data import Cat_Data
from Miss_Data import Miss_Data
from Feature_scaling_mean_normalization import Feature_scaling_mean_normalization
import csv
import pandas as pd
import numpy as np
from tkinter import *
from weighted_matrix import weighted_matrix
from SLP import SLP

algorthms_type = ["hebb_network", "weighted_matrix", "SLP"]


def readfile(filename):
    with open(filename, 'r') as f:
        reader = csv.reader(f)
        your_list = list(reader)
    return your_list


# x=np.full((4,2), [[1,1],[1,-1],[-1,1],[-1,-1]]);
# y=np.full((4,1), [[1],[1],[1],[-1]])

# ANN=XO(dataset)(x,y)

dataset = readfile("dataset.csv")
dataset = np.array(dataset)
print(dataset)
featureNames = dataset[0, :]
dataset = np.delete(dataset, 0, 0)

## for categorical the data
cat_data = Cat_Data(dataset, featureNames)


# dataset = cat_data.clean(use_defaul=True)  # pandas dataset
# dataset = dataset.replace(r'^\s*$', np.nan, regex=True)  # replace blank to NaN
# dataset = dataset.astype(np.float)  # convert string to float
#
# print("After cat_data ...")
# print(dataset);
#
# ## check for missing data
# miss_data = Miss_Data(dataset)
# dataset = miss_data.clean()
#
# print("After miss_data ...")
# print(dataset)
#
# # Feature_scaling_mean_normalization
# feature_scaling = Feature_scaling_mean_normalization(dataset)
# dataset = feature_scaling.clean()
#
# print("After Feature_scaling_mean_normalization ...")
# print(dataset)


# GUI function
###################################################################
#################################################################3
###################################################################
########################################################


def push_key_function():
    col_name = col_name_input.get("1.0", 'end-1c')
    key = key_input.get("1.0", 'end-1c')
    value = value_input.get("1.0", 'end-1c')
    cat_data.push_key_value(col_name, key, value)
    print(cat_data.map)


def cat_data_button_function():
    global dataset
    pandas_dataset = cat_data.clean(use_defaul=False)
    dataset=pandas_dataset
    dataset = dataset.replace(r'^\s*$', np.nan, regex=True)  # replace blank to NaN
    dataset = dataset.astype(np.float)  # convert string to float
    print(dataset)


def cat_data_button_default_function():
    global dataset
    dataset = cat_data.clean(use_defaul=True)
    dataset = dataset.replace(r'^\s*$', np.nan, regex=True)  # replace blank to NaN
    dataset = dataset.astype(np.float)  # convert string to float
    print(dataset)


def missing_data_function():
    global dataset
    miss_data = Miss_Data(dataset)
    dataset = miss_data.clean()
    print(dataset)


def feature_scaling_button_function():
    global dataset
    feature_scaling = Feature_scaling_mean_normalization(dataset)
    dataset = feature_scaling.clean()  # GUI
    print(dataset)


def select_algorithm_button_function():
    global algorthms_list
    global dataset
    select = "hebb_network"
    for i in algorthms_type:
        if i == algorthms_list.get():
            select = i
            break
    if select == "hebb_network":
        x_len, y_len = dataset.shape
        X = dataset.values[:, :-1]
        Y = dataset.values[:, -1:]
        [Weights, biaes, error] = Hebb_network(dataset)(X, Y)
        print("Weights")
        print(Weights)
        print("biaes")
        print(biaes)
        print("error")
        print(error)
    elif select == "weighted_matrix":
        input_w_m = weight_matrix_input_num.get("1.0", 'end-1c')
        output_w_m = weight_matrix_output_num.get("1.0", 'end-1c')
        input_w_m = int(input_w_m)
        output_w_m = int(output_w_m)
        X = dataset.values[:, :-output_w_m]
        Y = dataset.values[:, -output_w_m:]
        X=np.matrix(X)
        Y=np.matrix(Y)

        WM = weighted_matrix(input_w_m, output_w_m)(X, Y)
    elif select == "SLP":
        input_w_m = weight_matrix_input_num.get("1.0", 'end-1c')
        output_w_m = weight_matrix_output_num.get("1.0", 'end-1c')
        input_w_m = int(input_w_m)
        output_w_m = int(output_w_m)
        X = dataset.values[:, :-output_w_m]
        Y = dataset.values[:, -output_w_m:]
        # X = np.matrix(X)
        # Y = np.matrix(Y)
        [Weights, biaes, error]=SLP(input_w_m)(X, Y)
        print("Weights")
        print(Weights)
        print("biaes")
        print(biaes)
        print("error")
        print(error)


###################################################################
#################################################################3
###################################################################
########################################################

root = Tk()
root.title("XO Project")
root.geometry("600x600")
frame = Frame(root)

titlelable = Label(frame, text="XO project")
doted_row = Label(frame, text="-----------------------------------------------")
cat_data_title = Label(frame, text="Cat data")
col_name_lable = Label(frame, text="Row Name")
col_name_input = Text(frame, height=1)
key_lable = Label(frame, text="Key")
key_input = Text(frame, height=1)
value_lable = Label(frame, text="Value")
value_input = Text(frame, height=1)
push_key = Button(frame, text="Push", command=lambda: push_key_function())
cat_data_button = Button(frame, text="Push all keys and Values", command=lambda: cat_data_button_function())
cat_data_button_defalt = Button(frame, text="Defualt for our Project",
                                command=lambda: cat_data_button_default_function())
missing_data_button = Button(frame, text="Missing Data", command=lambda: missing_data_function())
feature_scaling_button = Button(frame, text="Feature scaling mean normalization",
                                command=lambda: feature_scaling_button_function())
algorthms_list = StringVar();
algorthms_list.set(algorthms_type[0])
NN_algorthms_OptionMenu = OptionMenu(frame, algorthms_list, *algorthms_type)
select_algorithm_button = Button(frame, text="Select The Algorithm", command=lambda: select_algorithm_button_function())

weight_matrix_input_num_lable = Label(frame, text="Input columns ")
weight_matrix_output_num_lable = Label(frame, text="Output columns ")
weight_matrix_input_num = Text(frame, height=1, width=20)
weight_matrix_output_num = Text(frame, height=1, width=20)

titlelable.grid(row=0, column=0)
doted_row.grid(row=1)
cat_data_title.grid(row=2)
col_name_lable.grid(row=3, column=0)
col_name_input.grid(row=3, column=1)
key_lable.grid(row=4, column=0)
key_input.grid(row=4, column=1)
value_lable.grid(row=5, column=0)
value_input.grid(row=5, column=1)
push_key.grid(row=6)
cat_data_button.grid(row=7, column=0)
cat_data_button_defalt.grid(row=7, column=1)
missing_data_button.grid(row=8, column=0)
feature_scaling_button.grid(row=9, column=0)
NN_algorthms_OptionMenu.grid(row=10, column=0)
select_algorithm_button.grid(row=10, column=1)

weight_matrix_input_num_lable.grid(row=11, column=0)
weight_matrix_output_num_lable.grid(row=11, column=1)
weight_matrix_input_num.grid(row=12, column=0)
weight_matrix_output_num.grid(row=12, column=1)

frame.grid(row=0)
root.mainloop()
