import numpy as np
import csv


class Hebb_network:
    def __init__(self, dataset, biases=None, weights=None):
        if weights is None:
            input_units = 9
            self.weights = np.zeros(input_units)
        else:
            self.weights = weights
        if biases is None:
            output_units = 1
            self.biases = np.zeros(output_units)
        else:
            self.biases = biases

    @staticmethod
    def binary_activation(net):
        if net >= 0:
            return 1
        return -1

    def activation_feedforward(self, x_i):
        weighted_input = self.weights * x_i
        weighted_sum = weighted_input.sum()
        y_hat = self.binary_activation(weighted_sum + self.biases)
        return y_hat

    def learning(self, x, y):
        delta_weights = x * y
        self.weights += delta_weights
        self.biases += y

    def training_phase(self, x, y):
        for i in range(len(x)):
            y_hat = self.activation_feedforward(x[i, :])
            self.learning(x[i, :], y[i])

    def testing_phase(self, x, y):
        #print("Final weights: ", self.weights)
        #print("Final biases: ", self.biases)
        all_y_hat = []
        for i in range(len(x)):
            y_hat = self.activation_feedforward(x[i, :])
            # print(x[i,:], y_hat)
            all_y_hat.append(y_hat)
        all_y_hat = np.array(all_y_hat)

        return self.calculate_error(all_y_hat, y)

    def __call__(self, x, y):
        self.training_phase(x, y)
        error = self.testing_phase(x, y)
        #print("the bias")
        #print(self.biases)
        return [self.weights, self.biases, error]

    @staticmethod
    def calculate_error(y_hat, y):
        res = (y_hat - y)*(y_hat - y)
        return res.sum()/len(res)
