
import pandas as pd
from sklearn.preprocessing import Normalizer

class Feature_scaling_mean_normalization:
    def __init__(self,dataset):
        self.dataset = dataset


    def clean(self):
        normailzation = Normalizer()
        dataset = normailzation.fit_transform(self.dataset)
        pandas_dataset = pd.DataFrame(dataset)
        return pandas_dataset



